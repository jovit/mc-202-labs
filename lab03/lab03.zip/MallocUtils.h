#ifndef MALLOCUTILS_H
#define MALLOCUTILS_H

// validate if the malloc has not failed
void validate_malloc(void *pointer);

#endif
